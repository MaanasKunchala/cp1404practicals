import random

# 1. The smallest number is 5. The largest is 20.
# 2. The smallest number is 3. The largest is 9. Line 2 can't produce 4.
# 3. The smallest number is 2.5. The largest is 5.5.

print(random.randint(1, 100))
